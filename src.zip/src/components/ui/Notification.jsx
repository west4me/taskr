import { motion } from 'framer-motion';
import PropTypes from 'prop-types';
import { X } from 'lucide-react';

const Notification = ({ message, type = 'success', onClose }) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: -50 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -50 }}
      className={`fixed top-4 right-4 z-50 p-4 rounded-lg shadow-lg ${
        type === 'success' ? 'bg-green-500' : 'bg-blue-500'
      }`}
    >
      <div className="flex items-center gap-2">
        <p className="text-white">{message}</p>
        <button 
          onClick={onClose} 
          className="text-white hover:text-gray-200"
        >
          <X className="w-4 h-4" />
        </button>
      </div>
    </motion.div>
  );
};

Notification.propTypes = {
  message: PropTypes.string.isRequired,
  type: PropTypes.oneOf(['success', 'info']),
  onClose: PropTypes.func.isRequired
};

export default Notification;