import { useState, useEffect } from 'react';
import { Plus, CheckCircle2, LogOut } from 'lucide-react';
import { AnimatePresence } from 'framer-motion';
import UserProgress from './UserProgress';
import UserBadges from './UserBadges';
import TaskModal from '../tasks/TaskModal';
import TaskList from '../tasks/TaskList';
import CalendarView from '../tasks/CalendarView';
import { useAuth } from '../../contexts/AuthContext';
import { createTask, getUserTasks, updateTask, deleteTask } from '../../services/taskService';
import { updateUserXP, updateStreak, getUserProfile } from '../../services/userService';
import Notification from '../ui/Notification';
import { checkAndAwardBadges } from '../../services/badgeService';

const Dashboard = () => {
    const [showCompleted, setShowCompleted] = useState(false);
    const [isTaskModalOpen, setIsTaskModalOpen] = useState(false);
    const [viewMode, setViewMode] = useState('list');
    const [tasks, setTasks] = useState([]);
    const [loading, setLoading] = useState(true);
    const [notification, setNotification] = useState(null);
    const [userData, setUserData] = useState({
        level: 1,
        currentStreak: 0
    });
    const { user, logout } = useAuth();

    useEffect(() => {
        const loadData = async () => {
            try {
                const [userTasks, profile] = await Promise.all([
                    getUserTasks(user.uid),
                    getUserProfile(user.uid)
                ]);
                setTasks(userTasks);
                setUserData(profile);
            } catch (error) {
                console.error('Error loading data:', error);
            } finally {
                setLoading(false);
            }
        };

        loadData();
    }, [user.uid]);

    const handleCreateTask = async (taskData) => {
        try {
            const newTask = await createTask(user.uid, taskData);
            setTasks(prev => [...prev, newTask]);
        } catch (error) {
            console.error('Error creating task:', error);
        }
    };

    const handleTaskComplete = async (taskId) => {
        try {
            const taskToUpdate = tasks.find(t => t.id === taskId);
            await updateTask(taskId, {
                completed: !taskToUpdate.completed
            });

            if (!taskToUpdate.completed) {
                await updateUserXP(user.uid, taskToUpdate.xp);
                await updateStreak(user.uid);
                const updatedProfile = await getUserProfile(user.uid);
                setUserData(updatedProfile);

                const completedTasks = tasks.filter(t => t.completed).length + 1;
                const newBadges = await checkAndAwardBadges(user.uid, updatedProfile, completedTasks);

                if (newBadges.length > 0) {
                    setNotification({
                        message: `New Badge Earned: ${newBadges[0].name}!`,
                        type: 'success'
                    });
                }

                setUserData(updatedProfile);

                if (updatedProfile.level > userData.level) {
                    setNotification({
                        message: `Level Up! You're now level ${updatedProfile.level}!`,
                        type: 'success'
                    });
                }

                if (updatedProfile.currentStreak > userData.currentStreak) {
                    setNotification({
                        message: `${updatedProfile.currentStreak} day streak! Keep it up!`,
                        type: 'info'
                    });
                }
            }

            setTasks(prev => prev.map(task =>
                task.id === taskId ? { ...task, completed: !task.completed } : task
            ));
        } catch (error) {
            console.error('Error updating task:', error);
        }
    };

    const handleTaskDelete = async (taskId) => {
        try {
            await deleteTask(taskId);
            setTasks(prev => prev.filter(task => task.id !== taskId));
        } catch (error) {
            console.error('Error deleting task:', error);
        }
    };

    const visibleTasks = tasks.filter(task => showCompleted || !task.completed);

    if (loading) {
        return (
            <div className="min-h-screen bg-background flex items-center justify-center">
                <p className="text-white">Loading your quests...</p>
            </div>
        );
    }

    return (
        <div className="min-h-screen bg-background p-4 md:p-6">
            <header className="max-w-6xl mx-auto">
                <div className="flex justify-between items-center mb-8">
                    <h1 className="text-2xl font-bold text-white">QuestLog</h1>
                    <div className="flex gap-4">
                        <button
                            className="btn-primary flex items-center gap-2"
                            onClick={() => setIsTaskModalOpen(true)}
                        >
                            <Plus className="w-5 h-5" />
                            Create
                        </button>
                        <button
                            className="btn-secondary flex items-center gap-2"
                            onClick={() => setShowCompleted(!showCompleted)}
                        >
                            <CheckCircle2 className="w-5 h-5" />
                            {showCompleted ? 'Hide Completed' : 'Show Completed'}
                        </button>
                        <button
                            className={`btn-secondary flex items-center gap-2 ${viewMode === 'list' ? 'bg-primary' : ''
                                }`}
                            onClick={() => setViewMode('list')}
                        >
                            List View
                        </button>
                        <button
                            className={`btn-secondary flex items-center gap-2 ${viewMode === 'calendar' ? 'bg-primary' : ''
                                }`}
                            onClick={() => setViewMode('calendar')}
                        >
                            Calendar View
                        </button>
                        <button
                            onClick={logout}
                            className="btn-secondary flex items-center gap-2"
                        >
                            <LogOut className="w-5 h-5" />
                            Logout
                        </button>
                    </div>
                </div>
            </header>
            <main className="max-w-6xl mx-auto">
                <UserProgress userData={userData} />
                <UserBadges />
                {viewMode === 'list' ? (
                    <div className="bg-surface/50 rounded-xl p-6">
                        <h2 className="text-xl font-semibold mb-4">Your Tasks</h2>
                        <TaskList
                            tasks={visibleTasks}
                            onTaskComplete={handleTaskComplete}
                            onTaskDelete={handleTaskDelete}
                        />
                    </div>
                ) : (
                    <CalendarView tasks={tasks} />
                )}
            </main>

            <TaskModal
                isOpen={isTaskModalOpen}
                onClose={() => setIsTaskModalOpen(false)}
                onSubmit={handleCreateTask}
            />

            <AnimatePresence>
                {notification && (
                    <Notification
                        message={notification.message}
                        type={notification.type}
                        onClose={() => setNotification(null)}
                    />
                )}
            </AnimatePresence>
        </div>
    );
};

export default Dashboard;