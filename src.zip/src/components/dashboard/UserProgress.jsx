import { Trophy, Flame } from 'lucide-react';
import PropTypes from 'prop-types';

const UserProgress = ({ userData }) => {
    const xpToGo = userData.nextLevelXP - userData.currentXP;
    const progressPercentage = (userData.currentXP / userData.nextLevelXP) * 100;

    return (
        <div className="bg-surface rounded-xl p-6 mb-6">
            <div className="flex justify-between items-start mb-6">
                <div>
                    <h2 className="text-2xl font-bold text-white">Level {userData.level}</h2>
                    <p className="text-gray-400">{xpToGo} XP to next level</p>
                </div>
                <div className="flex items-center gap-4">
                    <div className="flex items-center gap-2">
                        <Flame className="w-5 h-5 text-orange-400" />
                        <div>
                            <p className="text-sm text-gray-400">Current Streak</p>
                            <p className="font-bold text-white">{userData.currentStreak} days</p>
                        </div>
                    </div>
                    <div className="flex items-center gap-2">
                        <Trophy className="w-5 h-5 text-yellow-400" />
                        <div>
                            <p className="text-sm text-gray-400">Longest Streak</p>
                            <p className="font-bold text-white">{userData.longestStreak} days</p>
                        </div>
                    </div>
                </div>
            </div>
            <div className="relative w-full h-4 bg-gray-700 rounded-full overflow-hidden">
                <div 
                    className="absolute left-0 top-0 h-full bg-primary transition-all duration-300"
                    style={{ width: `${progressPercentage}%` }}
                />
            </div>
        </div>
    );
};

UserProgress.propTypes = {
    userData: PropTypes.shape({
        level: PropTypes.number.isRequired,
        currentXP: PropTypes.number.isRequired,
        nextLevelXP: PropTypes.number.isRequired,
        currentStreak: PropTypes.number.isRequired,
        longestStreak: PropTypes.number.isRequired
    }).isRequired
};

export default UserProgress;