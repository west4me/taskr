import { Medal, Flame, Star, Trophy } from 'lucide-react';
import { useEffect, useState } from 'react';
import { useAuth } from '../../contexts/AuthContext';
import { getUserBadges } from '../../services/badgeService';

const UserBadges = () => {
    const [badges, setBadges] = useState([]);
    const { user } = useAuth();

    useEffect(() => {
        const loadBadges = async () => {
            const userBadges = await getUserBadges(user.uid);
            setBadges(userBadges);
        };
        loadBadges();
    }, [user.uid]);

    const getIcon = (badgeId) => {
        switch (badgeId) {
            case 'novice': return Medal;
            case 'streak_master': return Flame;
            case 'power_user': return Star;
            case 'xp_hunter': return Trophy;
            default: return Medal;
        }
    };

    return (
        <div className="bg-surface rounded-xl p-6 mb-6">
            <h2 className="text-xl font-semibold mb-4">Your Badges</h2>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {badges.map((badge) => {
                    const Icon = getIcon(badge.id);
                    return (
                        <div 
                            key={badge.id}
                            className={`flex flex-col items-center p-4 rounded-lg ${
                                badge.earned ? 'bg-secondary' : 'bg-gray-800/50'
                            }`}
                        >
                            <Icon 
                                className={`w-8 h-8 ${badge.earned ? badge.color : 'text-gray-600'} mb-2`}
                            />
                            <span className={badge.earned ? 'text-white' : 'text-gray-400'}>
                                {badge.name}
                            </span>
                            <span className="text-xs text-gray-500 mt-1 text-center">
                                {badge.description}
                            </span>
                        </div>
                    );
                })}
            </div>
        </div>
    );
};

export default UserBadges;