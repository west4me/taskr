import PropTypes from 'prop-types';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronDown, ChevronUp, Trash2, CheckCircle } from 'lucide-react';
import { useState } from 'react';

// TaskItem is defined within TaskList.jsx
const TaskItem = ({ task, onComplete, onDelete }) => {
    const [isExpanded, setIsExpanded] = useState(false);

    const getDifficultyColor = (difficulty) => {
        const colors = {
            easy: 'text-green-400',
            medium: 'text-yellow-400',
            hard: 'text-red-400'
        };
        return colors[difficulty] || 'text-gray-400';
    };

    return (
        <motion.div
            layout
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="bg-surface rounded-lg p-4 mb-3"
        >
            <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                    <button
                        onClick={() => onComplete(task.id)}
                        className={`p-1 rounded-full transition-colors ${task.completed
                                ? 'text-green-400 hover:text-green-300'
                                : 'text-gray-400 hover:text-white'
                            }`}
                    >
                        <CheckCircle className="w-5 h-5" />
                    </button>
                    <span className={task.completed ? 'line-through text-gray-500' : 'text-white'}>
                        {task.name}
                    </span>
                </div>
                <div className="flex items-center gap-2">
                    <span className="text-primary font-bold">{task.xp} XP</span>
                    <button
                        onClick={() => setIsExpanded(!isExpanded)}
                        className="p-1 text-gray-400 hover:text-white transition-colors"
                    >
                        {isExpanded ? (
                            <ChevronUp className="w-5 h-5" />
                        ) : (
                            <ChevronDown className="w-5 h-5" />
                        )}
                    </button>
                    <button
                        onClick={() => onDelete(task.id)}
                        className="p-1 text-gray-400 hover:text-error transition-colors"
                    >
                        <Trash2 className="w-5 h-5" />
                    </button>
                </div>
            </div>

            <AnimatePresence>
                {isExpanded && (
                    <motion.div
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: 'auto', opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        transition={{ duration: 0.2 }}
                        className="mt-4 pl-9 text-sm text-gray-400 space-y-2 overflow-hidden"
                    >
                        {task.description && (
                            <p>{task.description}</p>
                        )}
                        <div className="flex gap-4">
                            <span className={getDifficultyColor(task.difficulty)}>
                                {task.difficulty.charAt(0).toUpperCase() + task.difficulty.slice(1)} Difficulty
                            </span>
                            <span>
                                {task.priority.charAt(0).toUpperCase() + task.priority.slice(1)} Priority
                            </span>
                        </div>
                    </motion.div>
                )}
            </AnimatePresence>
        </motion.div>
    );
};

TaskItem.propTypes = {
    task: PropTypes.shape({
        id: PropTypes.string.isRequired,
        name: PropTypes.string.isRequired,
        description: PropTypes.string,
        difficulty: PropTypes.oneOf(['easy', 'medium', 'hard']).isRequired,
        priority: PropTypes.oneOf(['low', 'medium', 'high']).isRequired,
        completed: PropTypes.bool.isRequired,
        xp: PropTypes.number.isRequired
    }).isRequired,
    onComplete: PropTypes.func.isRequired,
    onDelete: PropTypes.func.isRequired
};

const TaskList = ({ tasks, onTaskComplete, onTaskDelete }) => {
    return (
        <div className="space-y-2">
            <AnimatePresence>
                {tasks.map(task => (
                    <TaskItem
                        key={task.id}
                        task={task}
                        onComplete={onTaskComplete}
                        onDelete={onTaskDelete}
                    />
                ))}
            </AnimatePresence>
        </div>
    );
};

TaskList.propTypes = {
    tasks: PropTypes.arrayOf(PropTypes.shape({
        id: PropTypes.string.isRequired,
        name: PropTypes.string.isRequired,
        description: PropTypes.string,
        difficulty: PropTypes.oneOf(['easy', 'medium', 'hard']).isRequired,
        priority: PropTypes.oneOf(['low', 'medium', 'high']).isRequired,
        completed: PropTypes.bool.isRequired,
        xp: PropTypes.number.isRequired
    })).isRequired,
    onTaskComplete: PropTypes.func.isRequired,
    onTaskDelete: PropTypes.func.isRequired
};

export default TaskList;