import { useState } from 'react';
import Modal from '../ui/Modal';
import PropTypes from 'prop-types';

const TaskModal = ({ isOpen, onClose, onSubmit }) => {
  const [taskData, setTaskData] = useState({
    name: '',
    description: '',
    deadline: '',
    difficulty: 'medium', // easy, medium, hard
    priority: 'medium',   // low, medium, high
    isSoloTask: true
  });

  const calculateXP = () => {
    const baseXP = {
      easy: 50,
      medium: 100,
      hard: 150
    }[taskData.difficulty];

    const priorityMultiplier = {
      low: 1,
      medium: 1.2,
      high: 1.5
    }[taskData.priority];

    return Math.round(baseXP * priorityMultiplier);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit({
      ...taskData,
      xp: calculateXP()
    });
    onClose();
  };

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setTaskData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose} title="Create New Task">
      <form onSubmit={handleSubmit} className="space-y-6">
        <div>
          <label className="block text-sm font-medium text-gray-200 mb-2">
            Task Name
          </label>
          <input
            type="text"
            name="name"
            value={taskData.name}
            onChange={handleChange}
            className="w-full bg-gray-700 border border-gray-600 rounded-lg px-4 py-2 text-white focus:outline-none focus:border-primary"
            required
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-200 mb-2">
            Description
          </label>
          <textarea
            name="description"
            value={taskData.description}
            onChange={handleChange}
            rows="3"
            className="w-full bg-gray-700 border border-gray-600 rounded-lg px-4 py-2 text-white focus:outline-none focus:border-primary"
          />
        </div>

        <div>
        <label className="block text-sm font-medium text-gray-200 mb-2">
            Deadline
        </label>
        <input
            type="date"
            name="deadline"
            value={taskData.deadline}
            onChange={handleChange}
            className="w-full bg-gray-700 border border-gray-600 rounded-lg px-4 py-2 text-white focus:outline-none focus:border-primary"
        />
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-200 mb-2">
              Difficulty
            </label>
            <select
              name="difficulty"
              value={taskData.difficulty}
              onChange={handleChange}
              className="w-full bg-gray-700 border border-gray-600 rounded-lg px-4 py-2 text-white focus:outline-none focus:border-primary"
            >
              <option value="easy">Easy</option>
              <option value="medium">Medium</option>
              <option value="hard">Hard</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-200 mb-2">
              Priority
            </label>
            <select
              name="priority"
              value={taskData.priority}
              onChange={handleChange}
              className="w-full bg-gray-700 border border-gray-600 rounded-lg px-4 py-2 text-white focus:outline-none focus:border-primary"
            >
              <option value="low">Low</option>
              <option value="medium">Medium</option>
              <option value="high">High</option>
            </select>
          </div>
        </div>

        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <input
              type="checkbox"
              name="isSoloTask"
              checked={taskData.isSoloTask}
              onChange={handleChange}
              className="w-4 h-4 text-primary border-gray-600 rounded focus:ring-primary bg-gray-700"
            />
            <label className="ml-2 text-sm text-gray-200">
              Solo Task
            </label>
          </div>
          <div className="text-right">
            <p className="text-sm text-gray-400">Total XP</p>
            <p className="text-xl font-bold text-primary">{calculateXP()} XP</p>
          </div>
        </div>

        <div className="flex justify-end gap-4">
          <button
            type="button"
            onClick={onClose}
            className="btn-secondary"
          >
            Cancel
          </button>
          <button
            type="submit"
            className="btn-primary"
          >
            Create Task
          </button>
        </div>
      </form>
    </Modal>
  );
};

TaskModal.propTypes = {
    isOpen: PropTypes.bool.isRequired,
    onClose: PropTypes.func.isRequired,
    onSubmit: PropTypes.func.isRequired
  };

export default TaskModal;