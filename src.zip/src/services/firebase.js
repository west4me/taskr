import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';

// Your web app's Firebase configuration
const firebaseConfig = {
    apiKey: "AIzaSyAE2sbHiBFBfCsyvksv7A6kgMDTgPKe8qU",
    authDomain: "questlog-ad65a.firebaseapp.com",
    projectId: "questlog-ad65a",
    storageBucket: "questlog-ad65a.firebasestorage.app",
    messagingSenderId: "558295035268",
    appId: "1:558295035268:web:5ddb5d44fcc0e29ca741d1"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);