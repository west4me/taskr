import { doc, getDoc, updateDoc, arrayUnion } from 'firebase/firestore';
import { db } from './firebase';

const badges = {
    NOVICE: { id: 'novice', name: 'Novice', description: 'Complete your first task', icon: 'Medal', color: 'text-blue-400' },
    STREAK_MASTER: { id: 'streak_master', name: 'Streak Master', description: 'Maintain a 7-day streak', icon: 'Flame', color: 'text-orange-400' },
    POWER_USER: { id: 'power_user', name: 'Power User', description: 'Complete 10 tasks', icon: 'Star', color: 'text-yellow-400' },
    XP_HUNTER: { id: 'xp_hunter', name: 'XP Hunter', description: 'Reach level 5', icon: 'Trophy', color: 'text-purple-400' }
};

export const checkAndAwardBadges = async (userId, userData, completedTasksCount) => {
    const userRef = doc(db, 'users', userId);
    const userDoc = await getDoc(userRef);
    const earnedBadges = userDoc.data().badges || [];
    const newBadges = [];

    // Check each badge condition
    if (!earnedBadges.includes(badges.NOVICE.id) && completedTasksCount > 0) {
        newBadges.push(badges.NOVICE);
    }

    if (!earnedBadges.includes(badges.STREAK_MASTER.id) && userData.currentStreak >= 7) {
        newBadges.push(badges.STREAK_MASTER);
    }

    if (!earnedBadges.includes(badges.POWER_USER.id) && completedTasksCount >= 10) {
        newBadges.push(badges.POWER_USER);
    }

    if (!earnedBadges.includes(badges.XP_HUNTER.id) && userData.level >= 5) {
        newBadges.push(badges.XP_HUNTER);
    }

    if (newBadges.length > 0) {
        await updateDoc(userRef, {
            badges: arrayUnion(...newBadges.map(badge => badge.id))
        });
    }

    return newBadges;
};

export const getAllBadges = () => Object.values(badges);

export const getUserBadges = async (userId) => {
    const userRef = doc(db, 'users', userId);
    const userDoc = await getDoc(userRef);
    const earnedBadgeIds = userDoc.data().badges || [];
    
    return Object.values(badges).map(badge => ({
        ...badge,
        earned: earnedBadgeIds.includes(badge.id)
    }));
};