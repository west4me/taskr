import { doc, getDoc, setDoc, updateDoc } from 'firebase/firestore';
import { db } from './firebase';

export const initializeUserProfile = async (userId) => {
  try {
    const userRef = doc(db, 'users', userId);
    const userSnap = await getDoc(userRef);

    if (!userSnap.exists()) {
      const userData = {
        level: 1,
        currentXP: 0,
        totalXP: 0,
        currentStreak: 0,
        longestStreak: 0,
        lastActiveDate: new Date().toISOString().split('T')[0],
        nextLevelXP: 1000, // XP needed for level 2
      };
      await setDoc(userRef, userData);
      return userData;
    }

    return userSnap.data();
  } catch (error) {
    console.error('Error initializing user profile:', error);
    throw error;
  }
};

export const getUserProfile = async (userId) => {
  try {
    const userRef = doc(db, 'users', userId);
    const userSnap = await getDoc(userRef);
    
    if (!userSnap.exists()) {
      return await initializeUserProfile(userId);
    }
    
    return userSnap.data();
  } catch (error) {
    console.error('Error getting user profile:', error);
    throw error;
  }
};

export const updateUserXP = async (userId, xpGained) => {
  try {
    const userRef = doc(db, 'users', userId);
    const userSnap = await getDoc(userRef);
    const userData = userSnap.data();

    const newTotalXP = userData.totalXP + xpGained;
    const newCurrentXP = userData.currentXP + xpGained;

    // Check if user should level up
    let { level, nextLevelXP } = userData;
    while (newCurrentXP >= nextLevelXP) {
      level += 1;
      nextLevelXP = calculateNextLevelXP(level);
    }

    await updateDoc(userRef, {
      totalXP: newTotalXP,
      currentXP: newCurrentXP,
      level,
      nextLevelXP
    });

    return {
      level,
      currentXP: newCurrentXP,
      nextLevelXP
    };
  } catch (error) {
    console.error('Error updating user XP:', error);
    throw error;
  }
};

export const updateStreak = async (userId) => {
  try {
    const userRef = doc(db, 'users', userId);
    const userSnap = await getDoc(userRef);
    const userData = userSnap.data();

    const today = new Date().toISOString().split('T')[0];
    const lastActive = userData.lastActiveDate;
    
    let { currentStreak, longestStreak } = userData;
    
    // If last active was yesterday, increment streak
    const yesterday = new Date();
    yesterday.setDate(yesterday.getDate() - 1);
    const yesterdayStr = yesterday.toISOString().split('T')[0];
    
    if (lastActive === yesterdayStr) {
      currentStreak += 1;
      longestStreak = Math.max(currentStreak, longestStreak);
    } else if (lastActive !== today) {
      // Reset streak if not active yesterday (and not already logged in today)
      currentStreak = 1;
    }

    await updateDoc(userRef, {
      lastActiveDate: today,
      currentStreak,
      longestStreak
    });

    return { currentStreak, longestStreak };
  } catch (error) {
    console.error('Error updating streak:', error);
    throw error;
  }
};

const calculateNextLevelXP = (level) => {
  // Basic XP curve: each level requires 20% more XP than the previous
  return Math.round(1000 * Math.pow(1.2, level - 1));
};