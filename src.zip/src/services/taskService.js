import { db } from './firebase';
import {
    collection,
    addDoc,
    updateDoc,
    deleteDoc,
    doc,
    query,
    where,
    getDocs
} from 'firebase/firestore';

export const createTask = async (userId, taskData) => {
    try {
        const tasksRef = collection(db, 'tasks');
        const task = {
            ...taskData,
            userId,
            completed: false,
            createdAt: new Date().toISOString()
        };
        const docRef = await addDoc(tasksRef, task);
        return { id: docRef.id, ...task };
    } catch (error) {
        console.error('Error creating task:', error);
        throw error;
    }
};

export const getUserTasks = async (userId) => {
    try {
        const tasksRef = collection(db, 'tasks');
        const q = query(tasksRef, where('userId', '==', userId));
        const querySnapshot = await getDocs(q);
        return querySnapshot.docs.map(doc => ({
            id: doc.id,
            ...doc.data()
        }));
    } catch (error) {
        console.error('Error fetching tasks:', error);
        throw error;
    }
};

export const updateTask = async (taskId, updates) => {
    try {
        const taskRef = doc(db, 'tasks', taskId);
        await updateDoc(taskRef, updates);
        return { id: taskId, ...updates };
    } catch (error) {
        console.error('Error updating task:', error);
        throw error;
    }
};

export const deleteTask = async (taskId) => {
    try {
        const taskRef = doc(db, 'tasks', taskId);
        await deleteDoc(taskRef);
        return taskId;
    } catch (error) {
        console.error('Error deleting task:', error);
        throw error;
    }
};