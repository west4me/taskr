import { AuthProvider, useAuth } from './contexts/AuthContext';
import Dashboard from "./components/dashboard/Dashboard";
import LoginForm from './components/auth/LoginForm';

function AppContent() {
    const { user } = useAuth();
    return user ? <Dashboard /> : <LoginForm />;
}


function App() {
    return (
        <AuthProvider>
            <AppContent />
        </AuthProvider>
    );
}

export default App;